﻿
// zhalanView.cpp: CzhalanView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "zhalan.h"
#endif

#include "zhalanDoc.h"
#include "zhalanView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CzhalanView

IMPLEMENT_DYNCREATE(CzhalanView, CView)

BEGIN_MESSAGE_MAP(CzhalanView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CzhalanView 构造/析构

CzhalanView::CzhalanView() noexcept
{
	// TODO: 在此处添加构造代码

}

CzhalanView::~CzhalanView()
{
}

BOOL CzhalanView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CzhalanView 绘图

void CzhalanView::OnDraw(CDC* pDC)
{
    CRect rect;
    GetClientRect(&rect);

    int numHorizontal = 10;
    int numVertical = 10;

    int spacingX = rect.Width() / numHorizontal;
    int spacingY = rect.Height() / numVertical;

    for (int i = 0; i < numHorizontal; i++) {
        for (int j = 0; j < numVertical; j++) {
            int centerX = i * spacingX + spacingX / 2;
            int centerY = j * spacingY + spacingY / 2;

            int bigSquareSize = 100;
            int smallSquareSize =60;

            int bigSquareLeft = centerX - (bigSquareSize / 2);
            int bigSquareTop = centerY - (bigSquareSize / 2);
            int smallSquareLeft = centerX - (smallSquareSize / 2);
            int smallSquareTop = centerY - (smallSquareSize / 2);

            CPen pen(PS_SOLID, 1, RGB(0, 0, 0));
            CPen* pOldPen = pDC->SelectObject(&pen);

            pDC->Rectangle(bigSquareLeft, bigSquareTop, bigSquareLeft + bigSquareSize, bigSquareTop + bigSquareSize);
            pDC->Rectangle(smallSquareLeft, smallSquareTop, smallSquareLeft + smallSquareSize, smallSquareTop + smallSquareSize);

            pDC->MoveTo(centerX, j * spacingY);
            pDC->LineTo(centerX, (j + 1) * spacingY);

            pDC->MoveTo(i * spacingX, centerY);
            pDC->LineTo((i + 1) * spacingX, centerY);

            pDC->SelectObject(pOldPen);
        }
    }
}


// CzhalanView 打印

BOOL CzhalanView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CzhalanView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CzhalanView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CzhalanView 诊断

#ifdef _DEBUG
void CzhalanView::AssertValid() const
{
	CView::AssertValid();
}

void CzhalanView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CzhalanDoc* CzhalanView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CzhalanDoc)));
	return (CzhalanDoc*)m_pDocument;
}
#endif //_DEBUG


// CzhalanView 消息处理程序
