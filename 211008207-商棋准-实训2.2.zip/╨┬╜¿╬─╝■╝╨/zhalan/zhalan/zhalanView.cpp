﻿
// zhalanView.cpp: CzhalanView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "zhalan.h"
#endif

#include "zhalanDoc.h"
#include "zhalanView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CzhalanView

IMPLEMENT_DYNCREATE(CzhalanView, CView)

BEGIN_MESSAGE_MAP(CzhalanView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CzhalanView 构造/析构

CzhalanView::CzhalanView() noexcept
{
	// TODO: 在此处添加构造代码

}

CzhalanView::~CzhalanView()
{
}

BOOL CzhalanView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CzhalanView 绘图

void CzhalanView::OnDraw(CDC* pDC)
{
    // 获取视图矩形
    CRect rect;
    GetClientRect(&rect);

    // 计算每个小方块的大小
    int blockWidth = rect.Width() / 10;
    int blockHeight = rect.Height() / 10;

    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            // 计算当前方块的中心点坐标
            int centerX = blockWidth * i + blockWidth / 2;
            int centerY = blockHeight * j + blockHeight / 2;

            // 定义方框边长
            int length1 = blockWidth - 20; // 最大的方框
            int length2 = blockWidth / 2 - 10; // 中间的方框

            // 计算方框的矩形区域
            CRect rect1(centerX - length1 / 2, centerY - length1 / 2, centerX + length1 / 2, centerY + length1 / 2);
            CRect rect2(centerX - length2 / 2, centerY - length2 / 2, centerX + length2 / 2, centerY + length2 / 2);

            // 绘制方框
            pDC->Rectangle(rect1);
            pDC->Rectangle(rect2);

            // 绘制垂直线和水平线
            pDC->MoveTo(centerX, blockHeight * j);
            pDC->LineTo(centerX, blockHeight * (j + 1));
            pDC->MoveTo(blockWidth * i, centerY);
            pDC->LineTo(blockWidth * (i + 1), centerY);
        }
    }
}
// CzhalanView 打印

BOOL CzhalanView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CzhalanView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CzhalanView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CzhalanView 诊断

#ifdef _DEBUG
void CzhalanView::AssertValid() const
{
	CView::AssertValid();
}

void CzhalanView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CzhalanDoc* CzhalanView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CzhalanDoc)));
	return (CzhalanDoc*)m_pDocument;
}
#endif //_DEBUG


// CzhalanView 消息处理程序
