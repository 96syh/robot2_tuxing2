﻿
// shixunView.cpp: CshixunView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "shixun.h"
#endif

#include "shixunDoc.h"
#include "shixunView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CshixunView

IMPLEMENT_DYNCREATE(CshixunView, CView)

BEGIN_MESSAGE_MAP(CshixunView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

// CshixunView 构造/析构

CshixunView::CshixunView() noexcept
{
	// TODO: 在此处添加构造代码

}

CshixunView::~CshixunView()
{
}

BOOL CshixunView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CshixunView 绘图

void CshixunView::OnDraw(CDC* pDC)
{
	CshixunDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	CRect rect;
	GetClientRect(&rect);

	int cellWidth = rect.Width() / 10;
	int cellHeight = rect.Height() / 10;

	CBrush lightBrush(RGB(255, 255, 255)); // Light color for chessboard
	CBrush darkBrush(RGB(0, 0, 0));   // Dark color for chessboard

	CBrush* pOldBrush = nullptr;

	for (int row = 0; row < 10; row++)
	{
		for (int col = 0; col < 10; col++)
		{
			pOldBrush = pDC->SelectObject((row + col) % 2 == 0 ? &lightBrush : &darkBrush);
			pDC->Rectangle(col * cellWidth, row * cellHeight, (col + 1) * cellWidth, (row + 1) * cellHeight);
			pDC->SelectObject(pOldBrush);
		}
	}
}


// CshixunView 打印

BOOL CshixunView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CshixunView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CshixunView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CshixunView 诊断

#ifdef _DEBUG
void CshixunView::AssertValid() const
{
	CView::AssertValid();
}

void CshixunView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CshixunDoc* CshixunView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CshixunDoc)));
	return (CshixunDoc*)m_pDocument;
}
#endif //_DEBUG


// CshixunView 消息处理程序


void CshixunView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	P0 = point;
	CView::OnLButtonDown(nFlags, point);
}


void CshixunView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	CView::OnLButtonUp(nFlags, point);
}
