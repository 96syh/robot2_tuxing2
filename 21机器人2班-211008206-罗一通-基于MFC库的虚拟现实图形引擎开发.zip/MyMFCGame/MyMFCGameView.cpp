﻿
// MyMFCGameView.cpp: CMyMFCGameView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "MyMFCGame.h"
#endif

#include "MyMFCGameDoc.h"
#include "MyMFCGameView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


//定时器的名称用宏比较清楚
#define TIMER_PAINT 1
#define TIMER_HEROMOVE 2
#define TIMER_MONSTERMOVE 5
#define TIMER_HEROATTACK 3
#define TIMER_ARROW 4
//四个方向
#define DOWN 0
#define LEFT 1
#define RIGHT 2
#define UP 3


//#include "bmp.h"
//#include "ScaleBiliner.h"
// CMyMFCGameView

IMPLEMENT_DYNCREATE(CMyMFCGameView, CView)

BEGIN_MESSAGE_MAP(CMyMFCGameView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_KEYDOWN()
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_KEYUP()
END_MESSAGE_MAP()


//将png贴图透明
void TransparentPNG(CImage* png)
{
	for (int i = 0; i < png->GetWidth(); i++)
	{
		for (int j = 0; j < png->GetHeight(); j++)
		{
			unsigned char* pucColor = reinterpret_cast<unsigned char*>(png->GetPixelAddress(i, j));
			pucColor[0] = pucColor[0] * pucColor[3] / 255;
			pucColor[1] = pucColor[1] * pucColor[3] / 255;
			pucColor[2] = pucColor[2] * pucColor[3] / 255;
		}
	}
}

// CMyMFCGameView 构造/析构

CMyMFCGameView::CMyMFCGameView() noexcept
{
	// TODO: 在此处添加构造代码

}

CMyMFCGameView::~CMyMFCGameView()
{
}

BOOL CMyMFCGameView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1), NULL);

	//加载背景
	m_bg.Load(CString("./res/background.png"));
	//加载英雄图片
	MyHero.hero.Load(CString("./res/player1_w.png"));
	HeroAttack.attack.Load(CString("./res/player1_f.png"));
	MonsterAttack.attack.Load(CString("./res/player2_f.png"));
	Arrow.arrow.Load(CString("./res/player1_a.png"));
	Monster.hero.Load(CString("./res/player2_w.png"));
	dead1.hero.Load(CString("./res/player1_d.png"));
	dead2.hero.Load(CString("./res/player2_d.png"));

	TransparentPNG(&MyHero.hero);
	TransparentPNG(&Monster.hero);
	TransparentPNG(&HeroAttack.attack);
	TransparentPNG(&MonsterAttack.attack);
	TransparentPNG(&Arrow.arrow);
	TransparentPNG(&dead1.hero);
	TransparentPNG(&dead2.hero);

	MyHero.width = 80;
	MyHero.height = 100;
	//初始化英雄状态
	MyHero.direct = DOWN;
	MyHero.frame = 0;
	//设置英雄初始位置
	MyHero.x = 340;
	MyHero.y = 320;

	Monster.width = 80;
	Monster.height = 100;
	//初始化英雄状态
	Monster.direct = DOWN;
	Monster.frame = 0;
	//设置英雄初始位置
	Monster.x = 10;
	Monster.y = 10;

	Arrow.width = 64 / 2;
	Arrow.height =192 / 2;
	return TRUE;
}

// CMyMFCGameView 绘图


void CMyMFCGameView::OnDraw(CDC* pDC)
{
	CMyMFCGameDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	
	// TODO: 在此处为本机数据添加绘制代码
	CDC* cDC;

	cDC = this->GetDC();   //获得当前窗口的DC   
	GetClientRect(&m_client);   //获得窗口的尺寸
	//
	////加入我们要绘制的代码
	
	//创建缓冲DC
	m_cacheDC.CreateCompatibleDC(NULL);
	m_cacheCBitmap.CreateCompatibleBitmap(cDC, m_client.Width(), m_client.Height());
	m_cacheDC.SelectObject(&m_cacheCBitmap);

	//————————————————————开始绘制——————————————————————
	//贴背景,现在贴图就是贴在缓冲DC：m_cache中了
	m_bg.Draw(m_cacheDC, m_client);
	if (END == FALSE) 
	{
		if (fight == FALSE) {
			//贴英雄
			MyHero.hero.Draw(m_cacheDC, MyHero.x, MyHero.y, 48, 64, MyHero.frame * 48, MyHero.direct * 64, 48, 64);
		}
		else {
			//贴英雄攻击
			HeroAttack.attack.Draw(m_cacheDC, MyHero.x, MyHero.y, 64, 64, MyHero.frame * 64, MyHero.direct * 64, 64, 64);
			switch (MyHero.direct)
			{
			case DOWN:
				Arrow.arrow.Draw(m_cacheDC, Arrow.x + 45, Arrow.y + 55, 64 / 2, 192 / 2, MyHero.frame * 16, MyHero.direct * 48, 16, 48);
				break;
			case LEFT:
				Arrow.arrow.Draw(m_cacheDC, Arrow.x + 10, Arrow.y + 23, 64 / 2, 192 / 2, MyHero.frame * 16, MyHero.direct * 48, 16, 48);
				break;
			case RIGHT:
				Arrow.arrow.Draw(m_cacheDC, Arrow.x + 55, Arrow.y + 23, 64 / 2, 192 / 2, MyHero.frame * 16, MyHero.direct * 48, 16, 48);
				break;
			case UP:
				Arrow.arrow.Draw(m_cacheDC, Arrow.x + 40, Arrow.y - 60, 64 / 2, 192 / 2, MyHero.frame * 16, MyHero.direct * 48, 16, 48);
				break;
			default:
				break;
			}
		}


		if (Monster_fight == FALSE)
		{
			Monster.hero.Draw(m_cacheDC, Monster.x, Monster.y, 48, 64, Monster.frame * 48, Monster.direct * 64, 48, 64);
		}
		else
		{
			MonsterAttack.attack.Draw(m_cacheDC, Monster.x, Monster.y, 64, 64, Monster.frame * 64, Monster.direct * 64, 64, 64);
		}
		//怪物状态更新
		//水平方向上靠近
		if (FANGXIANG == 0)
		{
			if (Monster.x < MyHero.x)
			{
				Monster.x += 2;
				Monster.direct = RIGHT;
			}
			else if (Monster.x > MyHero.x)
			{
				Monster.x -= 2;
				Monster.direct = LEFT;
			}
			else
			{
				FANGXIANG = 1;
			}
		}
		else
		{
			//竖直方向上靠近
			if (Monster.y < MyHero.y)
			{
				Monster.direct = DOWN;
				Monster.y += 2;
			}
			else if (Monster.y > MyHero.y)
			{
				Monster.direct = UP;
				Monster.y -= 2;
			}
			else
			{
				FANGXIANG = 0;
			}
		}


		MyHero.Xcenter = MyHero.x + MyHero.width / 2;
		MyHero.Ycenter = MyHero.y + MyHero.height / 2;
		Monster.Xcenter = Monster.x + Monster.width / 2;
		Monster.Ycenter = Monster.y + Monster.height / 2;

		Arrow.Xcenter = Arrow.x + Arrow.width / 2;   //这里
		Arrow.Ycenter = Arrow.y + Arrow.height / 2;

		if (Monster.Xcenter< MyHero.Xcenter + (MyHero.width / 2 + Monster.width / 2) &&
			Monster.Xcenter> MyHero.Xcenter - (MyHero.width / 2 + Monster.width / 2) &&
			Monster.Ycenter< MyHero.Ycenter + (MyHero.height / 2 + Monster.height / 2) &&
			Monster.Ycenter> MyHero.Ycenter - (MyHero.height / 2 + Monster.height / 2)) {
			Monster_fight = TRUE;
			live--;
		}
		else
			Monster_fight = FALSE;

		if (Monster.Xcenter< Arrow.Xcenter + (Arrow.width / 2 + Monster.width / 2) &&
			Monster.Xcenter> Arrow.Xcenter - (Arrow.width / 2 + Monster.width / 2) &&
			Monster.Ycenter< Arrow.Ycenter + (Arrow.height / 2 + Monster.height / 2) &&
			Monster.Ycenter> Arrow.Ycenter - (Arrow.height / 2 + Monster.height / 2)) {
			live2-=10;
		}



		//最后将缓冲DC内容输出到窗口DC中
		cDC->BitBlt(0, 0, m_client.Width(), m_client.Height(), &m_cacheDC, 0, 0, SRCCOPY);


		CString data;
		cDC->SetTextColor(RGB(255, 255, 255));
		cDC->SetBkMode(TRANSPARENT);
		data.Format(CString("英雄血量： %d / 1000"), live);
		cDC->TextOutW(0, 0, data);
		data.Format(CString("敌人血量： %d / 1000"), live2);
		cDC->TextOutW(570, 0, data);

		if (live < 0 || live2 < 0) 
		{
			END = TRUE;
		}
	}
	else
	{
		
		if (live < live2) 
		{
			dead1.hero.Draw(m_cacheDC, MyHero.x, MyHero.y, 48, 48, Monster.frame * 48, Monster.direct * 48, 48, 48);
			cDC->BitBlt(0, 0, m_client.Width(), m_client.Height(), &m_cacheDC, 0, 0, SRCCOPY);
			cDC->SetTextColor(RGB(255, 0, 0));
			cDC->SetBkMode(RGB(255, 0, 0));
			cDC->TextOutW(320, 340, CString("游戏结束，你输了..."));
		}
		else
		{
			dead2.hero.Draw(m_cacheDC, Monster.x, Monster.y, 48, 48, Monster.frame * 48, Monster.direct * 48, 48, 48);
			cDC->BitBlt(0, 0, m_client.Width(), m_client.Height(), &m_cacheDC, 0, 0, SRCCOPY);
			cDC->SetTextColor(RGB(0, 0, 255));
			cDC->SetBkMode(RGB(255, 0, 0));
			cDC->TextOutW(320, 340, CString("游戏结束，你赢了！！！"));
		}
	}
	

	//————————————————————绘制结束—————————————————————

	//在绘制完图后,使窗口区有效
	ValidateRect(&m_client);
	//释放缓冲DC
	m_cacheDC.DeleteDC();
	//释放对象
	m_cacheCBitmap.DeleteObject();
	//释放窗口DC
	ReleaseDC(cDC);
}


// CMyMFCGameView 打印

BOOL CMyMFCGameView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CMyMFCGameView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CMyMFCGameView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CMyMFCGameView 诊断

#ifdef _DEBUG
void CMyMFCGameView::AssertValid() const
{
	CView::AssertValid();
}

void CMyMFCGameView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMyMFCGameDoc* CMyMFCGameView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyMFCGameDoc)));
	return (CMyMFCGameDoc*)m_pDocument;
}
#endif //_DEBUG


// CMyMFCGameView 消息处理程序


void CMyMFCGameView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	
	//nChar表示按下的键值
	switch (nChar)
	{
	case 'd':         //游戏中按下的键当然应该不区分大小写了
	case 'D':
		if (fight == FALSE) 
		{
			MyHero.direct = RIGHT;
			MyHero.x += 30;
			Arrow.x = MyHero.x;
			if (MyHero.x > 720)
			{
				MyHero.x = 720;
			}
		}
		break;
	case 'a':
	case 'A':
		if (fight == FALSE)
		{
			MyHero.direct = LEFT;
			MyHero.x -= 30;
			Arrow.x = MyHero.x;
			if (MyHero.x < -15)
			{
				MyHero.x = -15;
			}
		}
		break;
	case 'w':
	case 'W':
		if (fight == FALSE) 
		{
			MyHero.direct = UP;
			MyHero.y -= 30;
			Arrow.y = MyHero.y;
			if (MyHero.y < -15)
			{
				MyHero.y = -15;
			}
		}
		break;
	case 's':
	case 'S':
		if (fight == FALSE) 
		{
			MyHero.direct = DOWN;
			MyHero.y += 30;
			Arrow.y = MyHero.y;
			if (MyHero.y > 650)
			{
				MyHero.y = 650;
			}
		}
		break;
	case 'j':
	case 'J':
		if (click == 0) 
		{
			Arrow.y = MyHero.y;
			Arrow.x = MyHero.x;
			fight = TRUE;
		}
		click++;
		break;
	}
}




void CMyMFCGameView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	switch (nIDEvent)
	{
	case TIMER_PAINT:OnPaint(); break;  //若是重绘定时器，就执行OnPaint函数
	case TIMER_HEROMOVE:               //控制人物移动的定时器
	{
		MyHero.frame++;              //每次到了间隔时间就将图片换为下一帧
		if (MyHero.frame == 4)          //到最后了再重头开始
			MyHero.frame = 0;
		Monster.frame++;              //每次到了间隔时间就将图片换为下一帧
		if (Monster.frame == 4)          //到最后了再重头开始
			Monster.frame = 0;
	}
	break;
	case TIMER_HEROATTACK:               //控制人物移动的定时器
	{
		HeroAttack.frame++;              //每次到了间隔时间就将图片换为下一帧
		if (HeroAttack.frame == 4)          //到最后了再重头开始
			HeroAttack.frame = 0;
		MonsterAttack.frame++;              //每次到了间隔时间就将图片换为下一帧
		if (MonsterAttack.frame == 4)         //到最后了再重头开始
		{
			MonsterAttack.frame = 0;
		}
			
	}
	break;
	case TIMER_ARROW:
		switch (MyHero.direct)
		{
		case DOWN:
			Arrow.y += 5;
			break;
		case LEFT:
			Arrow.x -= 5;
			break;
		case RIGHT:
			Arrow.x += 5;
			break;
		case UP:
			Arrow.y -= 5;
			break;
		default:
			break;
		}
	break;
	}
}


int CMyMFCGameView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  在此添加您专用的创建代码
	
	//创建一个10毫秒产生一次消息的定时器
	SetTimer(TIMER_PAINT, 10, NULL);
	//创建人物行走动画定时器
	SetTimer(TIMER_HEROMOVE, 100, NULL);
	//创建人物攻击动画定时器
	SetTimer(TIMER_HEROATTACK, 100, NULL);
	//创建弓箭攻击定时器
	SetTimer(TIMER_ARROW, 5, NULL);

	return 0;
}


void CMyMFCGameView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	
	switch (nChar)
	{
	case 'j':
	case 'J':
		click = 0;
		fight = FALSE;
		break;
	}
	
}
