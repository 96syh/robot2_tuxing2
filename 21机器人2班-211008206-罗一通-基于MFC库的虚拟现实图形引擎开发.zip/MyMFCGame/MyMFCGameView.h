﻿
// MyMFCGameView.h: CMyMFCGameView 类的接口
//

#pragma once


class CMyMFCGameView : public CView
{
// 仅从序列化创建
protected: 
	CMyMFCGameView() noexcept;
	DECLARE_DYNCREATE(CMyMFCGameView)

// 特性
public:
	CMyMFCGameDoc* GetDocument() const;

	CRect m_client;    //保存客户区大小
	CImage m_bg;      //背景图片

	struct shero
	{
		CImage hero;     //保存英雄的图像
		int x;             //保存英雄的位置
		int y;
		int direct;        //英雄的方向
		int frame;         //运动到第几张图片

		int width;          //图片的宽度和高度，用于碰撞判定
		int height;
		int Xcenter;
		int Ycenter;

	}MyHero,Monster,dead1,dead2;

	struct move
	{
		CImage attack;     //保存英雄攻击的图像
		int x;             //保存英雄的位置
		int y;
		int direct;        //英雄的方向
		int frame;         //运动到第几张图片
	}HeroAttack,MonsterAttack;

	struct wappon
	{
		CImage arrow;     //保存英雄攻击的图像
		int x;             //保存英雄的位置
		int y;
		int direct;        //英雄的方向
		int frame;         //运动到第几张图片

		int width;          //图片的宽度和高度，用于碰撞判定
		int height;
		int Xcenter;
		int Ycenter;
	}Arrow;

	CDC m_cacheDC;   //缓冲DC
	CBitmap m_cacheCBitmap;//缓冲位图
	BOOL fight = FALSE,Monster_fight = FALSE;
	int click = 0;
	int FANGXIANG = 0;
	int live = 1000;
	int live2 = 1000;
	BOOL END = FALSE;
// 操作
public:

// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 实现
public:
	virtual ~CMyMFCGameView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // MyMFCGameView.cpp 中的调试版本
inline CMyMFCGameDoc* CMyMFCGameView::GetDocument() const
   { return reinterpret_cast<CMyMFCGameDoc*>(m_pDocument); }
#endif

