﻿
// sqzView.cpp: CsqzView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "sqz.h"
#endif

#include "sqzDoc.h"
#include "sqzView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsqzView

IMPLEMENT_DYNCREATE(CsqzView, CView)

BEGIN_MESSAGE_MAP(CsqzView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()

// CsqzView 构造/析构

CsqzView::CsqzView() noexcept
{
	// TODO: 在此处添加构造代码

}

CsqzView::~CsqzView()
{
}

BOOL CsqzView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}


void CsqzView::OnDraw(CDC* pDC)
{
    CsqzDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    if (!pDoc)
        return;

    const int nBoardSize = 10;
    const int nSquareSize = 50; 

    CRect rect;
    GetClientRect(&rect);
    int nStartX = (rect.Width() - nBoardSize * nSquareSize) / 2;
    int nStartY = (rect.Height() - nBoardSize * nSquareSize) / 2;

    CBrush whiteBrush(RGB(255, 255, 255)); 
    CBrush blackBrush(RGB(0, 0, 0));       
    CPen gridPen(PS_SOLID, 1, RGB(0, 0, 0)); 

    CPen* pOldPen = pDC->SelectObject(&gridPen);
    CBrush* pOldBrush = pDC->SelectObject(&whiteBrush);

    for (int i = 0; i < nBoardSize; ++i)
    {
        for (int j = 0; j < nBoardSize; ++j)
        {
            CBrush* pBrush = ((i + j) % 2 == 0) ? &whiteBrush : &blackBrush;
            pDC->SelectObject(pBrush);

            pDC->Rectangle(nStartX + i * nSquareSize, nStartY + j * nSquareSize,
                nStartX + (i + 1) * nSquareSize, nStartY + (j + 1) * nSquareSize);
        }
    }

    pDC->SelectObject(pOldBrush);
    pDC->SelectObject(pOldPen);
}


// CsqzView 打印

BOOL CsqzView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CsqzView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CsqzView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CsqzView 诊断

#ifdef _DEBUG
void CsqzView::AssertValid() const
{
	CView::AssertValid();
}

void CsqzView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CsqzDoc* CsqzView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CsqzDoc)));
	return (CsqzDoc*)m_pDocument;
}
#endif //_DEBUG


// CsqzView 消息处理程序


void CsqzView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	P0 = point;
	CView::OnLButtonDown(nFlags, point);
}


void CsqzView::OnLButtonUp(UINT nFlags, CPoint point)
{
    P1 = point; 
    CView::OnLButtonUp(nFlags, point);
}
