﻿//{{NO_DEPENDENCIES}}
// 生成的 Microsoft Visual C++ 包含文件。
// 由 sqz.rc 使用
//
#define IDD_ABOUTBOX				100
#define IDP_OLE_INIT_FAILED			100
#define IDR_MAINFRAME				128
#define IDR_sqzTYPE				130

// 新对象的下一组默认值
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	310
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		310
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
