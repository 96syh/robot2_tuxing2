﻿
// 棋盘2View.cpp: C棋盘2View 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "棋盘2.h"
#endif

#include "棋盘2Doc.h"
#include "棋盘2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// C棋盘2View

IMPLEMENT_DYNCREATE(C棋盘2View, CView)

BEGIN_MESSAGE_MAP(C棋盘2View, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// C棋盘2View 构造/析构

C棋盘2View::C棋盘2View() noexcept
{
	// TODO: 在此处添加构造代码

}

C棋盘2View::~C棋盘2View()
{
}

BOOL C棋盘2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// C棋盘2View 绘图

void C棋盘2View::OnDraw(CDC*pDC /*pDC*/)
{
	C棋盘2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	int squareSize = 100;
	int boardWidth = squareSize * 10;
	int boardHeight = squareSize * 10;

	CBrush bkBrush(RGB(0, 0, 0));
	CBrush* pOldBrush = pDC->SelectObject(&bkBrush);
	pDC->Rectangle(0, 0, boardWidth, boardHeight);
	pDC->SelectObject(pOldBrush);

	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			int x = j * squareSize;
			int y = i * squareSize;
			if ((i + j) % 2 == 0)
			{
				CBrush lightBrush(RGB(255, 255, 255)); // 白色  
				pOldBrush = pDC->SelectObject(&lightBrush);
				pDC->Rectangle(x, y, x + squareSize, y + squareSize);
				pDC->SelectObject(pOldBrush);
			}
			else
			{
				CBrush darkBrush(RGB(0, 0, 0)); // 深色  
				pOldBrush = pDC->SelectObject(&darkBrush);
				pDC->Rectangle(x, y, x + squareSize, y + squareSize);
				pDC->SelectObject(pOldBrush);
			}
		}
	}
}
	// TODO: 在此处为本机数据添加绘制代码



// C棋盘2View 打印

BOOL C棋盘2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void C棋盘2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void C棋盘2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// C棋盘2View 诊断

#ifdef _DEBUG
void C棋盘2View::AssertValid() const
{
	CView::AssertValid();
}

void C棋盘2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

C棋盘2Doc* C棋盘2View::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(C棋盘2Doc)));
	return (C棋盘2Doc*)m_pDocument;
}
#endif //_DEBUG


// C棋盘2View 消息处理程序
