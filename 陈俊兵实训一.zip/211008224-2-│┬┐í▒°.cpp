#include <iostream>
using namespace std;
#define chenjunbing 3.14;
#include<math.h>
void shixun(double* x, double* y, int a, int b, double theta) {
	double x1 = 0;
	double y1 = 0;
	double x2 = 0;
	double y2 = 0;

	x1 = *x;
	y1 = *y;
	x2 = x1 * cos(theta) - y1 * sin(theta) + cos(theta) * a - sin(theta) * b - a;
	y2 = x1 * sin(theta) + y1 * cos(theta) + sin(theta) * a + cos(theta) * b - b;
	*x = x2;
	*y = y2;
}
int main() {
	double x = 0;
	double y = 0;
	double x1 = 0;
	double y1 = 0;
	double x2 = 0;
	double y2 = 0;
	x = 10.0;
	y = 10.0;
	x1 = 30;
	y1 = 10;
	x2 = 20;
	y2 = 25;
	int a = 10;
	int b = 25;
	double theta = chenjunbing;
	theta = theta / 6;
	shixun(&x, &y, a, b, theta);
	cout << "陈俊兵" << x << endl;
	cout << "陈俊兵" << y << endl;
	shixun(&x1, &y1, a, b, theta);
	cout << "陈俊兵" << x1 << endl;
	cout << "陈俊兵" << y1 << endl;
	shixun(&x2, &y2, a, b, theta);
	cout << "陈俊兵" << x2 << endl;
	cout << "陈俊兵" << y2 << endl;
}

2.一个三角形由P0（10，10）、P1（30，10）、P2（20，25）构成，将其以点（0，1）为原点，以直线y=2x+1为y轴的参考系下的坐标，要求将变换方式写成函数通用形式，使用一维数组传递点的数值，用自己的名字代表角度，使用main函数调用函数，将结果打印出来。
#include <iostream>
using namespace std;
#define chenjunbing 3.14;
#include<math.h>

void shixun(2)(double* x, double* y, double k, int a, int b, double* resultx, double* resulty) {
	double theta = chenjunbing;
	theta = theta / 2;
	for (int i = 0; i < 3; i++) {
		resultx[i] = x[i] * cos(theta - atan(k)) - y[i] * sin(theta - atan(k)) - a * cos(theta - atan(k)) + b * sin(theta - atan(k)) + a;
		resulty[i] = x[i] * sin(theta - atan(k)) + y[i] * cos(theta - atan(k)) - a * sin(theta - atan(k)) - b * cos(theta - atan(k)) + b;

	}
}
int main() {

	int a = 0;
	int b = 1;
	double k = 2;
	double x[3] = { 0 };
	double y[3] = { 0 };
	x[0] = 10;
	x[1] = 30;
	x[2] = 20;
	y[0] = 10;
	y[1] = 10;
	y[2] = 25;
	double resultx[3] = { 0 };
	double resulty[3] = { 0 };
	shixun(2)(x, y, k, a, b, resultx, resulty);
	for (int i = 0; i < 3; i++) {
		cout << "陈俊兵" << resultx[i] << endl;
		cout << "陈俊兵" << resulty[i] << endl;
	}
	return 0;

