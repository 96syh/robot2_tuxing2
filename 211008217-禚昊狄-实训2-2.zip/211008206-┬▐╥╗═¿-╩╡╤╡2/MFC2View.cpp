﻿
// MFC2View.cpp: CMFC2View 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "MFC2.h"
#endif

#include "MFC2Doc.h"
#include "MFC2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFC2View

IMPLEMENT_DYNCREATE(CMFC2View, CView)

BEGIN_MESSAGE_MAP(CMFC2View, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CMFC2View 构造/析构

CMFC2View::CMFC2View() noexcept
{
	// TODO: 在此处添加构造代码

}

CMFC2View::~CMFC2View()
{
}

BOOL CMFC2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CMFC2View 绘图
void CMFC2View::Createrect(int x, int y, CDC* pDC) {
    // 设定正方形的尺寸  
    int outerSquareSize = 200; // 外部大正方形的尺寸  
    int innerSquareSize = 100; // 内部小正方形的尺寸  
    int size = 300;
    // 计算小正方形的中心位置  
    int centerX = outerSquareSize / 2;
    int centerY = outerSquareSize / 2;

    // 绘制外部大正方形  
    pDC->Rectangle(x-centerX, x - centerX, y+centerY, y + centerY);

    // 绘制内部小正方形  
    pDC->Rectangle(x - innerSquareSize / 2, y +innerSquareSize / 2,
        x + innerSquareSize / 2, y + innerSquareSize / 2);
    //横线
    pDC->MoveTo(10 * size, (x+1)*size);
    pDC->LineTo(10*size, (y + 1) * size);
    //竖线
    pDC->MoveTo((x + 1) * size, 10 * size);
    pDC->LineTo((y + 1) * size, 10 * size);
}

  
void CMFC2View::OnDraw(CDC* pDC)
{
    CMFC2Doc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    if (!pDoc)
        return;

    // 网格单元的大小和间距  
    int cellSize = 50; // 每个网格单元的大小  
    int spacing = 10;  // 网格单元之间的间距  

    // 计算整个网格的总宽度和高度  
    int gridWidth = (cellSize + spacing) * 10 - spacing; // 减去最后一个间距  
    int gridHeight = gridWidth; // 假设网格是正方形的  

    // 设置画笔和画刷  
    CPen pen(PS_SOLID, 1, RGB(0, 0, 0)); // 黑色画笔  
    CBrush brush(RGB(255, 255, 255));    // 白色画刷（可选，用于填充背景或其他用途）  
    CPen* pOldPen = pDC->SelectObject(&pen);
    CBrush* pOldBrush = pDC->SelectObject(&brush);

    // 遍历每个网格单元并绘制  
    for (int i = 0; i < 10; ++i)
    {
        for (int j = 0; j < 10; ++j)
        {
            // 计算当前网格单元的位置  
            int x = j * (cellSize + spacing);
            int y = i * (cellSize + spacing);

            // 绘制大正方形  
            pDC->Rectangle(x, y, x + cellSize, y + cellSize);

            // 计算小正方形的位置  
            int innerX = x + (cellSize - cellSize / 2) / 2; // 假设小正方形是大正方形的一半  
            int innerY = y + (cellSize - cellSize / 2) / 2;

            // 绘制小正方形  
            pDC->Rectangle(innerX, innerY, innerX + cellSize / 2, innerY + cellSize / 2);

            // 绘制中心线（横线）  
            pDC->MoveTo(x + cellSize / 2, y-5);
            pDC->LineTo(x + cellSize / 2, y + cellSize+5);

            // 绘制中心线（竖线）  
            pDC->MoveTo(x-5, (y + cellSize / 2));
            pDC->LineTo(x+5 + cellSize, y + cellSize / 2);
        }
    }

    // 恢复原来的画笔和画刷  
    pDC->SelectObject(pOldPen);
    pDC->SelectObject(pOldBrush);
}


// CMFC2View 打印

BOOL CMFC2View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CMFC2View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CMFC2View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CMFC2View 诊断

#ifdef _DEBUG
void CMFC2View::AssertValid() const
{
	CView::AssertValid();
}

void CMFC2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFC2Doc* CMFC2View::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFC2Doc)));
	return (CMFC2Doc*)m_pDocument;
}
#endif //_DEBUG


// CMFC2View 消息处理程序
