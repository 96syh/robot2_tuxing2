﻿
// MFCzhalanView.cpp: CMFCzhalanView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "MFCzhalan.h"
#endif

#include "MFCzhalanDoc.h"
#include "MFCzhalanView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFCzhalanView

IMPLEMENT_DYNCREATE(CMFCzhalanView, CView)

BEGIN_MESSAGE_MAP(CMFCzhalanView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CMFCzhalanView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CMFCzhalanView 构造/析构

CMFCzhalanView::CMFCzhalanView() noexcept
{
	// TODO: 在此处添加构造代码

}

CMFCzhalanView::~CMFCzhalanView()
{
}

BOOL CMFCzhalanView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CMFCzhalanView 绘图

void CMFCzhalanView::Createrect(int x, int y, CDC* pDC)
{
    // 设定正方形的尺寸  
    int outerSquareSize = 200; // 外部大正方形的尺寸  
    int innerSquareSize = 100; // 内部小正方形的尺寸  
    int size = 300;
    // 计算小正方形的中心位置  
    int centerX = outerSquareSize / 2;
    int centerY = outerSquareSize / 2;

    // 绘制外部大正方形  
    pDC->Rectangle(x - centerX, x - centerX, y + centerY, y + centerY);

    // 绘制内部小正方形  
    pDC->Rectangle(x - innerSquareSize / 2, y + innerSquareSize / 2,
        x + innerSquareSize / 2, y + innerSquareSize / 2);
    //横线
    pDC->MoveTo(10 * size, (x + 1) * size);
    pDC->LineTo(10 * size, (y + 1) * size);
    //竖线
    pDC->MoveTo((x + 1) * size, 10 * size);
    pDC->LineTo((y + 1) * size, 10 * size);
}


void CMFCzhalanView::OnDraw(CDC* pDC)
{
    CMFCzhalanDoc* pDoc = GetDocument();
    ASSERT_VALID(pDoc);
    if (!pDoc)
        return;


    int cellSize = 50;
    int spacing = 10;


    int gridWidth = (cellSize + spacing) * 10 - spacing;
    int gridHeight = gridWidth;

    // 设置画笔和画刷  
    CPen pen(PS_SOLID, 1, RGB(0, 0, 0));
    CBrush brush(RGB(255, 255, 255));
    CPen* pOldPen = pDC->SelectObject(&pen);
    CBrush* pOldBrush = pDC->SelectObject(&brush);


    for (int i = 0; i < 10; ++i)
    {
        for (int j = 0; j < 10; ++j)
        {

            int x = j * (cellSize + spacing);
            int y = i * (cellSize + spacing);


            pDC->Rectangle(x, y, x + cellSize, y + cellSize);


            int innerX = x + (cellSize - cellSize / 2) / 2; // 假设小正方形是大正方形的一半  
            int innerY = y + (cellSize - cellSize / 2) / 2;


            pDC->Rectangle(innerX, innerY, innerX + cellSize / 2, innerY + cellSize / 2);


            pDC->MoveTo(x + cellSize / 2, y - 5);
            pDC->LineTo(x + cellSize / 2, y + cellSize + 5);


            pDC->MoveTo(x - 5, (y + cellSize / 2));
            pDC->LineTo(x + 5 + cellSize, y + cellSize / 2);
        }
    }


    pDC->SelectObject(pOldPen);
    pDC->SelectObject(pOldBrush);
}


// CMFCzhalanView 打印


void CMFCzhalanView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CMFCzhalanView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CMFCzhalanView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CMFCzhalanView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}

void CMFCzhalanView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CMFCzhalanView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CMFCzhalanView 诊断

#ifdef _DEBUG
void CMFCzhalanView::AssertValid() const
{
	CView::AssertValid();
}

void CMFCzhalanView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMFCzhalanDoc* CMFCzhalanView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMFCzhalanDoc)));
	return (CMFCzhalanDoc*)m_pDocument;
}
#endif //_DEBUG


// CMFCzhalanView 消息处理程序
